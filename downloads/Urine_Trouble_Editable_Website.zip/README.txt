ARE YOU KIDNEY ME? — EDITABLE WEBSITE

Open index.html in a modern browser, or publish this folder to any static website host. No build command, account or backend is required for the game itself. All images are included.

Unlock Edit Content with the instructor password to change questions, answers, images, game names and settings. Changes save in this browser. Export an updated HTML or website ZIP to share the changes. Shared edits across devices are not automatic. The password is an interface lock for this offline/static site, not server authentication. Published changes still require repository access. After changing a password, publish the new editor-access.js to update the shared site. Keep the password privately; only a salted verifier is exported.

Use the same file and browser to resume where local-file storage is supported. Use Export score sheet for a portable score record.
