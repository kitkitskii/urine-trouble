ARE YOU KIDNEY ME? — EDITABLE WEBSITE

Open index.html in a modern browser, or publish this folder to any static website host. No build command, account or backend is required for the game itself. All images are included.

Use Edit Content to change questions, answers, images, game names and settings. Changes save in this browser. Export an updated HTML or website ZIP to share the changes. Shared edits across devices are not automatic.

Use the same file and browser to resume where local-file storage is supported. Use Export score sheet for a portable score record.
